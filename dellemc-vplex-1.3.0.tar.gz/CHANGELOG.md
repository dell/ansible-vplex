# Dellemc\.Vplex Release Notes

**Topics**

- <a href="#v1-3-0">v1\.3\.0</a>
    - <a href="#release-summary">Release Summary</a>

<a id="v1-3-0"></a>
## v1\.3\.0

<a id="release-summary"></a>
### Release Summary

This release adds enhancements to VPLEX module handling\, including improved storage view support and updated validations\.
