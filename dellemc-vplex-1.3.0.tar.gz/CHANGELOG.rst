===========================
Dellemc.Vplex Release Notes
===========================

.. contents:: Topics

v1.3.0
======

Release Summary
---------------

This release adds enhancements to VPLEX module handling, including improved storage view support and updated validations.
