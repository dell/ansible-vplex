# Dellemc\.Vplex Release Notes

**Topics**

- <a href="#v1-2-2">v1\.2\.2</a>
    - <a href="#release-summary">Release Summary</a>

<a id="v1-2-2"></a>
## v1\.2\.2

<a id="release-summary"></a>
### Release Summary

This is release 1\.2\.2 of <code>dellemc\.vplex</code>\, released on 2024\-04\-03\.
