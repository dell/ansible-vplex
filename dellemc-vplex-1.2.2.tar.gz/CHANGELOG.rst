===========================
Dellemc.Vplex Release Notes
===========================

.. contents:: Topics

v1.2.2
======

Release Summary
---------------

This is release 1.2.2 of ``dellemc.vplex``, released on 2024-04-03.
